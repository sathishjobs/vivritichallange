/**
 * Color Theme Controller
 */

 export default {
     primaryColor : '#3B3B98',
     secondaryColor : "#1B9CFC",
     textColor : ""
 }

