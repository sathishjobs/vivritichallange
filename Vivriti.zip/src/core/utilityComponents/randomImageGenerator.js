 // Generate Random beer image for better look
 export function randomImageNumberGenerator() {
    return Math.floor(Math.random() * 11) + 1;
  }