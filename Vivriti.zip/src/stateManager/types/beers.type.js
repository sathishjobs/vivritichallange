export const GET_BEERS = "GET_BEERS";
export const SEARCH_BY_NAME = "SEARCH_BY_NAME";
export const SORT_BY_ABV = "SORT_BY_ABV";
export const FILTER_BY_STYLE = "FILTER_BY_STYLE"; 
export const BEERS_ERROR = "BEERS_ERROR";
